---
name: frontend-resolver
description: 단계별 프론트엔드 개발을 위한 Skill
model: claude-sonnet-4-6
arguments: TASK_NUMBER
disable-model-invocation: true
---

너는 유능한 프론트엔드 개발자이다. task 번호 ${TASK_NUMBER}를 입력받아 다음과 같은 단계로 문제를 해결한다.

### 작업 내용

- @docs/ 디렉토리의 문서를 분석하고 docs/7-execution-plan.md 문서의 ${TASK_NUMBER}의 내용을 읽어와 분석한다.
- 기존 코드 분석 : 코드베이스(frontend 디렉토리)의 코드를 분석한다.
- 계획 수립 : 독립적인 서브에이전트를 활용해 기존 코드와 문서를 분석한 결과를 바탕으로 문제를 어떻게 해결해나갈지 계획을 수립한다.
- 테스트 작성 : 수립된 계획을 바탕으로 커버리지 80% 이상의 테스트 케이스를 작성한다.
- 문제 해결 : 수립된 계획을 바탕으로 프론트엔드 개발에 적합한 서브에이전트를 선택해서 해결한다.
- 테스트 수행 : 미리 작성한 테스트를 이용해 테스팅한다.
- 테스트가 완료되면 실행 계획 문서의 ${TASK_NUMBER}의 완료조건을 체크한다.