// supabase 클라이언트는 postgres.js(src/lib/db.ts)로 교체됨.
// 테스트 mock 참조 유지를 위해 파일 존재만 유지.
export const supabase = null;
