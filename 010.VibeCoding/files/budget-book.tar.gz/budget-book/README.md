# 공동 가계부 서비스

가족·친구·여행 그룹 등 복수의 사람이 함께 지출을 기록하고 정산할 수 있는 웹 기반 서비스입니다.  
개인 가계부가 아닌 **그룹 단위의 지출 기록과 정산**에 집중합니다.

---

## Demo

**https://budget-book-fe.vercel.app**

| 계정 | 역할 | 패스워드 |
|------|------|----------|
| user1@test.com | MANAGER (관리자) | asdf!2345 |
| user2@test.com | MEMBER | asdf!2345 |
| user3@test.com | MEMBER | asdf!2345 |

`user1@test.com`으로 로그인한 후 그룹 목록에서 **남미여행** 그룹을 선택하면 지출 기록, 정산, 리포트 등 주요 기능을 바로 테스트해볼 수 있습니다.

---

## 주요 기능

- 그룹 멤버 누구나 지출을 입력하여 기록 부담 분산
- 균등(N빵) / 개별 입력 두 가지 분담 방식 지원
- **기간 한정 그룹** (여행 등 단기) / **상시 그룹** (가족·정기 모임) 두 가지 유형 지원
- MANAGER가 기간을 지정하여 수동 정산 실행, 완료 시 전 멤버에게 인앱 메시지 자동 발송
- 카테고리별·멤버별 지출 통계 파이 차트 및 엑셀 내보내기

---

## 기술 스택

| 영역 | 기술 |
|------|------|
| Frontend | React + TypeScript (반응형 웹) |
| Backend | Node.js + Express |
| Database | Supabase (PostgreSQL) |
| 인증 | JWT (Access Token 1h / Refresh Token 30d) |

---

## 문서

| 문서 | 설명 |
|------|------|
| [도메인 정의서](docs/1-domain-definition.md) | 엔티티 정의, 비즈니스 규칙(BR/DR/SC), 입력 검증 규칙, 추적 매트릭스 |
| [PRD](docs/2-prd.md) | 기능 요구사항, 권한 매트릭스, 비기능 요구사항, MVP 로드맵 |
| [사용자 시나리오](docs/3-user-scenario.md) | 페르소나별 16개 시나리오 (주요 흐름 + 예외 흐름) |
| [프로젝트 구조 설계 원칙](docs/4-project-principle.md) | 레이어 구조, 네이밍 컨벤션, 테스트 전략, FE/BE 디렉토리 구조 |
| [아키텍처 다이어그램](docs/5-arch-diagram.md) | 시스템 구성, 인증 흐름, 정산 흐름, 초대 상태 전이 (Mermaid) |
| [ERD](docs/6-erd.md) | 10개 엔티티 관계도, 속성·제약·FK 전략, 주요 관계 설명 |
| [실행 계획](docs/7-execution-plan.md) | DB·BE·FE 79개 태스크, 체크박스형 완료 조건 및 의존성, 5단계 구현 순서 |
| [와이어프레임](docs/8-wireframe.md) | 전체 화면 구조, ASCII 와이어프레임, 권한별 UI 차이, 공통 컴포넌트 명세 |
| [Swagger 명세](swagger/swagger.json) | OpenAPI 3.0 REST API 명세 — 31개 엔드포인트, 스키마, 인증, 에러 응답 |

---

## 개발 범위 (MVP)

구현 우선순위: **인증 → 그룹 → 지출 → 정산 → 알림 → 리포트**

MVP 제외 항목 (v2 예정):
- 다중 통화 지원 및 환율 자동 계산
- Dark Mode
- 다국어 지원
- 이메일 정산 알림
