export default function NotFoundPage() {
  return (
    <div className="text-center p-12">
      <h1>404</h1>
      <p>페이지를 찾을 수 없습니다.</p>
    </div>
  );
}
